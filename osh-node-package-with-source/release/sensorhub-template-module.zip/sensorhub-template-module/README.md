### My New Module

Describe what the module does and what its limitations are (e.g. for sensor drivers the exact hardware that is supported should be listed here)
